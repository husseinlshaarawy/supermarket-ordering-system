import javax.swing.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class Main {
    public static void main(String[] args) {



        List<Item> items = new ArrayList<>();

        String[] products = {"Pizza", "Cheeseburger", "Coffee", "Soda", "Water"};
        double[] prices = {40.0, 20.0, 5.0, 4.0, 2.0};

        //System.out.println("Product List:");
        //for (int i = 0; i < products.length; i++) {
           // System.out.println(products[i] + ": $" + prices[i]);
        //}

        ShoppingCart cart = new ShoppingCart();

        while (true)
        {
            int action = Integer.parseInt(JOptionPane.showInputDialog("Our Products\nPizza: $40\nCheeseburger: $20\nCoffee: $5\nSoda: $4\nWater: $2\nChoose action: (1) Add Item | (2) Delete Item | (3) Checkout"));

            if (action == 1)
            {
                String name = JOptionPane.showInputDialog("Enter Item name");
                double price = 0;
                int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter Item quantity"));

                boolean validItem = false;
                for (int i = 0; i < products.length; i++) {
                    if (name.equalsIgnoreCase(products[i])) {
                        validItem = true;
                        price = prices[i];
                        break;
                    }
                }

                if (validItem)
                {
                    Item newItem = new Item(name, quantity, price);
                    items.add(newItem);
                    cart.add(newItem);
                }
                else
                {
                    JOptionPane.showMessageDialog(null, "Invalid item. Please choose from the predefined products.");
                }
            }

            else if (action == 2) {
                if (!items.isEmpty()) {
                    int index = Integer.parseInt(JOptionPane.showInputDialog("Enter the index of the item to delete"));
                    if (index >= 0 && index < items.size()) {
                        Item deletedItem = items.remove(index);
                        cart.remove(deletedItem);
                        JOptionPane.showMessageDialog(null, "Item deleted: " + deletedItem.getName());
                    } else {
                        JOptionPane.showMessageDialog(null, "Invalid index");
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "No items to delete.");
                }
            }

            else if (action == 3) {
                int response = JOptionPane.showConfirmDialog(null, "Do you want to checkout" , "Proceed to checkout", JOptionPane.YES_NO_OPTION);

                double totalAmount = cart.getTotalAmount();

                Discount discount = null;

                int hasDiscount = JOptionPane.showConfirmDialog(null, "Do you have a discount code?", "Discount", JOptionPane.YES_NO_OPTION);

                if (hasDiscount == JOptionPane.YES_OPTION) {

                    discount = new ApplyDiscount();
                    totalAmount = cart.getTotalAmount();


                    totalAmount = discount.applyDiscount(totalAmount);

                    String message = "The total amount after discount is: $" + totalAmount;

                    JOptionPane.showMessageDialog(null, message, "Total Amount Information", JOptionPane.INFORMATION_MESSAGE);
                } else {

                    totalAmount = cart.getTotalAmount();

                    String message = "The total amount is: $" + totalAmount;

                    JOptionPane.showMessageDialog(null, message, "Total Amount Information", JOptionPane.INFORMATION_MESSAGE);
                }


                if (response == JOptionPane.YES_OPTION) {
                    int paymentMethodType;
                    paymentMethodType = Integer.parseInt(JOptionPane.showInputDialog("Choose Payment Option | (1) PayPal | (2) Credit Card |"));

                    if (paymentMethodType == 1) {
                        int userBalance = 1223;
                        String userEmail = JOptionPane.showInputDialog("Enter Paypal email");
                        String userPassword = JOptionPane.showInputDialog("Enter Paypal password");

                        PayPal ppAccount = new PayPal(userEmail, userPassword, userBalance);

                        if (ppAccount.isValid()) {

                            String paymentResult = "Paypal \n" + cart.checkout(ppAccount, totalAmount);

                            JOptionPane.showMessageDialog(null, paymentResult);

                            String transactionReference = Transactions.generateRandomTransactionReference();

                            String paymentReceipt = "Transaction Reference #" + transactionReference + " has been paid successfully.\n"
                                    + "Total amount: $" + totalAmount  + "\n"
                                    + "Date and Time: " + Transactions.getCurrentDateTime();


                            JOptionPane.showMessageDialog(null, paymentReceipt);

                        } else {
                            JOptionPane.showMessageDialog(null, "Error: PayPal email or password is not valid. Please check your credentials and try again.");
                        }

                    }

                    else if (paymentMethodType == 2) {
                        String cardHolderName = JOptionPane.showInputDialog("Enter card holder name");
                        String cardNumber = JOptionPane.showInputDialog("Enter card number");
                        String dateString = JOptionPane.showInputDialog("Enter Expiry Date (MM/YY):");
                        int cvv = Integer.parseInt(JOptionPane.showInputDialog("Enter CVV:"));
                        int balance = 1212;

                        CreditCard creditCard = new CreditCard(cardHolderName, cardNumber, cvv);

                        Date expiryDate = CreditCard.parseMonthYear(dateString);

                        creditCard.setExpiryDate(expiryDate);

                        creditCard.setBalance(balance);

                        if (creditCard.isValid()) {

                            String paymentResult = "Paypal \n" + cart.checkout(creditCard, totalAmount);

                            JOptionPane.showMessageDialog(null, paymentResult);

                            String transactionReference = Transactions.generateRandomTransactionReference();

                            String paymentReceipt = "Transaction Reference #" + transactionReference + " has been paid successfully.\n"
                                    + "Total amount: $" + totalAmount + "Date and Time: " + Transactions.getCurrentDateTime();

                            JOptionPane.showMessageDialog(null, paymentReceipt);
                        }

                        else {
                            JOptionPane.showMessageDialog(null, "Credit card is not valid. Payment failed.");
                        }
                    }

                    else {
                        JOptionPane.showMessageDialog(null, "Invalid payment method");
                    }
                }
                break;
            }

            else {
                JOptionPane.showMessageDialog(null, "Invalid action");
            }
        }
    }

}
