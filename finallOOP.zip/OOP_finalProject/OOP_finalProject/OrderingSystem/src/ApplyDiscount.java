import javax.swing.JOptionPane;

public class ApplyDiscount extends Discount {
    @Override
    public double applyDiscount(double totalAmount) {
        String promoCode = JOptionPane.showInputDialog("Enter promo code (if any):");


        if (isValidPromoCode(promoCode)) {

            double discountAmount = totalAmount * 0.10;
            double discountedTotal = totalAmount - discountAmount;

            JOptionPane.showMessageDialog(null, "Promo code applied! Discount amount: $" + discountAmount);
            return discountedTotal;
        } else {
            JOptionPane.showMessageDialog(null, "Invalid promo code. No discount applied.");
            return totalAmount;
        }
    }

    private static boolean isValidPromoCode(String promoCode) {
        return promoCode != null && promoCode.equals("aast10%");
    }
}