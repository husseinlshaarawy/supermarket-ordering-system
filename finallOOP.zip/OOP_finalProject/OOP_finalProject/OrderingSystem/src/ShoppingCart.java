import java.awt.*;

public class ShoppingCart
{
    private Item[] orderItems;

    public ShoppingCart() {
        orderItems = new Item[10];
    }

    public void add(Item item){

        for (int i = 0; i < orderItems.length; i++){
            if (orderItems[i] == null){
                orderItems[i] = item;
                break;
            }
        }
    }

    public void remove(Item item){

        for (int i = 0; i < orderItems.length; i++){
            if (orderItems[i] == item){
                orderItems[i] = null;
                break;
            }
        }

    }


    public double getTotalAmount(){
        double totalAmount = 0.0;

        for (Item orderItem : orderItems){
            if (orderItem != null)
                totalAmount += orderItem.getPrice();
        }
        return totalAmount;
    }


    public String checkout(PaymentMethod paymentMethod, double totalAmount){
        return paymentMethod.pay((int) totalAmount);
    }

}
