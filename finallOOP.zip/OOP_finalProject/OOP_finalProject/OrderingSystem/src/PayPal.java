import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class PayPal implements PaymentMethod
{
    private String userEmail;
    private String userPassword;
    private int userBalance;

    public PayPal(String userEmail, String userPassword, int userBalance) {
        this.userEmail = userEmail;
        this.userPassword = userPassword;
        this.userBalance = userBalance;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public String getUserPassword() {
        return userPassword;
    }

    public void setUserPassword(String userPassword) {
        this.userPassword = userPassword;
    }

    public int getUserBalance() {
        return userBalance;
    }

    public void setUserBalance(int userBalance) {
        this.userBalance = userBalance;
    }

    @Override
    public boolean isValid() {
        boolean flag = true;

        String emailRegex = "^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}$";
        Pattern emailPattern = Pattern.compile(emailRegex);
        Matcher emailMatcher = emailPattern.matcher(userEmail);

        if (!emailMatcher.matches()) {
            flag = false;
        }

        String passwordRegex = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=!])(?=\\S+$).{8,}$";
        Pattern passwordPattern = Pattern.compile(passwordRegex);
        Matcher passwordMatcher = passwordPattern.matcher(userPassword);


        return flag;
    }

    @Override
    public String pay(int amount) {
        if (userBalance >= amount)
        {
            userBalance -= amount;
            return "Payment successful. Remaining balance: $" + userBalance;
        }
        else
        {
            return "insufficient funds";
        }
    }
}
