import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

public class Transactions
{
    public static String generateRandomTransactionReference() {
        int transactionReferenceLength = 8;

        String characters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        StringBuilder transactionReferenceBuilder = new StringBuilder(transactionReferenceLength);

        Random random = new Random();

        for (int i = 0; i < transactionReferenceLength; i++) {
            int index = random.nextInt(characters.length());
            char randomChar = characters.charAt(index);
            transactionReferenceBuilder.append(randomChar);
        }

        return transactionReferenceBuilder.toString();
    }

    static String getCurrentDateTime() {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return dateFormat.format(new Date());
    }
}
