public interface PaymentMethod
{
    boolean isValid();
    public String pay(int amount);
}
