import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class CreditCard implements PaymentMethod {
    private String cardHolderName;
    private String cardNumber;
    private int cvv;
    private Date expiryDate;
    private int balance;

    public CreditCard(String cardHolderName, String cardNumber, int cvv) {
        this.cardHolderName = cardHolderName;
        this.cardNumber = cardNumber;
        this.cvv = cvv;
    }

    public String getCardHolderName() {
        return cardHolderName;
    }

    public void setCardHolderName(String cardHolderName) {
        this.cardHolderName = cardHolderName;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getCvv() {
        return cvv;
    }

    public void setCvv(int cvv) {
        this.cvv = cvv;
    }

    public String getExpiryDate() {
        if (expiryDate != null) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yy");
            return dateFormat.format(expiryDate);
        } else {
            return null;
        }
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    @Override
    public boolean isValid() {
        boolean flag = true;

        Date currentDate = new Date();
        if (expiryDate != null) {

            if (expiryDate.before(currentDate)) {
                flag = false;
            }
        }
        else {
            flag = false;
        }

        return flag;
    }

    @Override
    public String pay(int amount) {
        if (isValid()) {
            if (balance >= amount) {
                balance -= amount;
                return "Payment successful. Remaining balance: $" + balance;
            } else {
                return "Insufficient funds in the credit card.";
            }
        } else {
            return "Credit card is not valid. Payment failed.";
        }
    }

    public static Date parseMonthYear(String input) {
        try {
            return new SimpleDateFormat("MM/yy").parse(input);
        }

        catch (ParseException e) {
            return null;
        }
    }
}
