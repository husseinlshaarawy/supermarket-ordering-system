public abstract class Discount {
    public abstract double applyDiscount(double totalAmount);
}
