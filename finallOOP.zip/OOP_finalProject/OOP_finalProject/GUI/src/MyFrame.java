import javax.swing.*;

public class MyFrame extends JFrame {

    MyFrame() {
        this.setTitle("Talabat"); // frame title
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // exit the app
        this.setResizable(false); // prevent frame from being resized
        this.setSize(420, 420); // set x and y dimensions
        this.setVisible(true); // veiw the frame on screen

        ImageIcon image = new ImageIcon("logo.png"); //create image icon
        this.setIconImage(image.getImage()); //icon

        //frame.getContentPane().setBackground(new Color()); //change color of background
    }
}
