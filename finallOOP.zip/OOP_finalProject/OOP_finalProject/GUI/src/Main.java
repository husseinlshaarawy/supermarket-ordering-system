import javax.swing.*;

public class Main
{
    public static void main(String[] args) {

        MyFrame MyFrame = new MyFrame();

        // JLabel = a GUI display area for a string of a text, an image or both

        //ImageIcon burger = new ImageIcon("burger.png");

        JLabel label = new JLabel();
        label.setText("Welcome to Talabat Order now!");
        //label.setIcon(burger);


        MyFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        MyFrame.setSize(500, 500);
        MyFrame.setVisible(true);
        MyFrame.add(label);
    }
}